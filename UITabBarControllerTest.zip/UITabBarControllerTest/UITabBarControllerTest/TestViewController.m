//
//  TestViewController.m
//  UITabBarControllerTest
//
//  Created by wangtao on 16/9/28.
//  Copyright © 2016年 wangtao. All rights reserved.
//

#import "TestViewController.h"

@interface TestViewController ()
@property (weak, nonatomic) IBOutlet UILabel *labelTest;

@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.labelName.length) {
        self.labelTest.text = self.labelName;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
