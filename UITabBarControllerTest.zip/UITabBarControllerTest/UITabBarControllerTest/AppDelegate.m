//
//  AppDelegate.m
//  UITabBarControllerTest
//
//  Created by wangtao on 16/9/28.
//  Copyright © 2016年 wangtao. All rights reserved.
//

#import "AppDelegate.h"
#import "TestViewController.h"

@interface AppDelegate () <UITabBarControllerDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    
    UITabBarController *tabbarVC = [[UITabBarController alloc]init];
    tabbarVC.delegate = self;
    
    TestViewController *test1VC = [[TestViewController alloc]init];
    test1VC.labelName = @"首页";
    test1VC.tabBarItem.title = @"首页";
    test1VC.tabBarItem.image = [UIImage imageNamed:@"tb_teacher_normal"];
    test1VC.tabBarItem.selectedImage = [UIImage imageNamed:@"tb_teacher_select"];
    
    TestViewController *test2VC = [[TestViewController alloc]init];
    test2VC.labelName = @"消息";
    test2VC.tabBarItem.title = @"消息";
    test2VC.tabBarItem.badgeValue = @"99+";
    test2VC.tabBarItem.image = [UIImage imageNamed:@"tb_message_normal"];
    test2VC.tabBarItem.selectedImage = [UIImage imageNamed:@"tb_message_select"];
    
    TestViewController *test3VC = [[TestViewController alloc]init];
    test3VC.labelName = @"朋友圈";
    test3VC.tabBarItem.title = @"朋友圈";
    test3VC.tabBarItem.image = [UIImage imageNamed:@"tab_circle"];
    test3VC.tabBarItem.selectedImage = [UIImage imageNamed:@"tab_circle_selected"];
    
    TestViewController *test4VC = [[TestViewController alloc]init];
    test4VC.labelName = @"我";
    test4VC.tabBarItem.title = @"我";
    test4VC.tabBarItem.image = [UIImage imageNamed:@"tb_me_normal"];
    test4VC.tabBarItem.selectedImage = [UIImage imageNamed:@"tb_me_select"];
    
//    [tabbarVC addChildViewController:test1VC];
//    [tabbarVC addChildViewController:test2VC];
//    [tabbarVC addChildViewController:test3VC];
//    [tabbarVC addChildViewController:test4VC];
    tabbarVC.viewControllers = @[test1VC,test2VC,test3VC,test4VC];
    
    self.window.rootViewController = tabbarVC;
    
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
    
    TestViewController *vc = (TestViewController *)viewController;
    if ([vc.labelName isEqualToString:@"消息"]) {
        [tabBarController.viewControllers objectAtIndex:1].tabBarItem.badgeValue = nil;
    }
    
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
