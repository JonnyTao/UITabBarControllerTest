//
//  TestViewController.h
//  UITabBarControllerTest
//
//  Created by wangtao on 16/9/28.
//  Copyright © 2016年 wangtao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestViewController : UIViewController

@property (nonatomic, copy) NSString *labelName;

@end
